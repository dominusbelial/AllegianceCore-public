import sys, json, struct, csv, io, re, hashlib
from pathlib import Path
from collections import Counter
sys.path.insert(0,str(Path(__file__).resolve().parent))
from p738_objects import ObjectReader
root=Path.cwd(); out=root/'docs/reports/P738_HD2_assets'
wd=Path((root/'.git').read_text().strip().split(': ',1)[1]); common=(wd/(wd/'commondir').read_text().strip()).resolve(); reader=ObjectReader(common)
def ref(name):
 p=common/name
 if p.exists(): return p.read_text().strip()
 for line in (common/'packed-refs').read_text().splitlines():
  if not line.startswith(('#','^')) and line.split()[1]==name:return line.split()[0]
 raise KeyError(name)
head=(wd/'HEAD').read_text().strip(); ours=ref(head[5:]) if head.startswith('ref: ') else head; theirs=(wd/'MERGE_HEAD').read_text().strip()
def parents(oid):return [line.split()[1].decode() for line in reader.read(oid).split(b'\n\n',1)[0].splitlines() if line.startswith(b'parent ')]
def ancestors(oid):
 seen=set(); todo=[oid]
 while todo:
  oid=todo.pop()
  if oid not in seen:seen.add(oid);todo.extend(parents(oid))
 return seen
commits=ancestors(ours)&ancestors(theirs); bases=commits-{p for c in commits for p in parents(c)}; assert len(bases)==1; base=bases.pop()
def flatten(oid,prefix=''):
 data=reader.read(oid);pos=0; result={}
 while pos<len(data):
  end=data.index(b'\0',pos);mode,name=data[pos:end].decode().split(' ',1);child=data[end+1:end+21].hex();pos=end+21
  if mode=='40000':result.update(flatten(child,prefix+name+'/'))
  else:result[prefix+name]=child
 return result
def tree(commit):return flatten(reader.read(commit).splitlines()[0].decode().split()[1])
B,O,T=map(tree,(base,ours,theirs))
def blob(tree,path):return reader.read(tree[path]) if path in tree else None
# Read the index without invoking any commands or changing repository metadata.
data=(wd/'index').read_bytes();sig,version,count=struct.unpack_from('!4sII',data);assert sig==b'DIRC' and version in (2,3);pos=12;conflicts={};paths=[]
for i in range(count):
 start=pos;flags=struct.unpack_from('!H',data,pos+60)[0];oid=data[pos+40:pos+60].hex();pos+=62
 if flags&0x4000:pos+=2
 end=data.index(b'\0',pos);name=data[pos:end].decode();pos=start+((end+1-start+7)//8)*8;paths.append(name)
 stage=(flags>>12)&3
 if stage:conflicts.setdefault(name,{})[stage]=oid
assert list(conflicts)==['tests/Allegiance.Core.Tests/P652EconomyDroneAiTests.cs'],conflicts
incoming=[p for p in sorted(B.keys()|T.keys()) if B.get(p)!=T.get(p)]
both=[p for p in incoming if O.get(p)!=B.get(p)]
print('Incoming changed paths:',len(incoming)); print('\n'.join(incoming)); print('Both changed:',both)
# Parity rows from all three snapshots, with working files checked byte-for-byte.
parity={}
for name in ('parity-matrix.csv','sim-rules-matrix.csv'):
 path='docs/parity/'+name; current=(root/path).read_bytes()
 def rows(raw):
  rs=list(csv.DictReader(io.StringIO(raw.decode('utf-8-sig'))));return {r.get('row_id',(r['area'],r['native_item'])):r for r in rs}
 b,o,t,c=map(rows,(blob(B,path),blob(O,path),blob(T,path),current))
 assert c==o and t==b
 parity[name]={'rows':len(c),'incoming_rows_unchanged_from_base':True,'master_rows_preserved':True,'LF':b'\r' not in current,'sha256':hashlib.sha256(current).hexdigest()};assert parity[name]['LF']
(out/'parity-row-audit.json').write_text(json.dumps(parity,indent=2)+'\n')
# Master audio and reports are unchanged by this graphics-only wave.
master_paths=['src/Allegiance.ClientCore.Game/Game1.Audio.cs','src/Allegiance.ClientCore/State/ClientSoundEvent.cs']
for path in master_paths:assert (root/path).read_bytes()==blob(O,path),path
lost_reports=[]
for path in O:
 if path.startswith('docs/reports/') and path.endswith('.md') and path in T and path!='docs/reports/HD2_PBR_CLIENT.md':
  if (root/path).exists() and (root/path).read_bytes()!=blob(O,path):lost_reports.append(path)
assert not lost_reports,lost_reports
# Flake notes must retain both complete parent texts, allowing the automatic union.
flakes=(root/'docs/TEST_FLAKES.md').read_text()
for label,tree_ in [('master',O),('incoming',T)]:
 # Compare lines: merge union may interleave appendices.
 missing=Counter(blob(tree_,'docs/TEST_FLAKES.md').decode().splitlines())-Counter(flakes.splitlines())
 assert not missing,(label,missing)
markers=[]
for name in set(paths):
 path=root/name
 if path.is_file() and re.search(rb'^(<<<<<<< .+|=======|>>>>>>> .+)$',path.read_bytes(),re.M):markers.append(name)
assert not markers,markers
summary={'ours':ours,'theirs':theirs,'base':base,'index_conflicted_paths':list(conflicts),'incoming_changed_paths':incoming,'both_changed_paths':both,'master_audio_preserved':master_paths,'master_reports_preserved':True,'test_flakes_parent_union_preserved':True,'remaining_conflict_markers':markers,'repository_metadata_modified':False}
(out/'resolution-audit.json').write_text(json.dumps(summary,indent=2)+'\n')
print('Audit passed; parity, master audio/reports, flake union, conflict-marker checks clean.')
