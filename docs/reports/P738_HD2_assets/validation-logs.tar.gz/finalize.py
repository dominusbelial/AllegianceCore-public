import json, hashlib, tarfile, re, sys
from pathlib import Path
from collections import Counter
import xml.etree.ElementTree as ET
root=Path.cwd();out=root/'docs/reports/P738_HD2_assets';scratch=Path(__file__).resolve().parent
ledger=json.loads((out/'verification.json').read_text());focused=[e for e in ledger if e['label'].startswith('focused-')];showcase=[e for e in ledger if e['label'].startswith('showcase-')];suites=[e for e in ledger if e['label'].startswith('suite-')];isolations=[e for e in ledger if e['label'].startswith('isolation-')]
assert len(focused)==219 and len(showcase)==5 and len(suites)==3
assert all(e['exitCode']==0 and int(e['counts']['total'])>0 and int(e['skippedCases'])==0 for e in focused+showcase)
qualification=[]
for suite in suites:
 for method in dict.fromkeys(f['method'] for f in suite.get('failures',[])):
  runs=[e for e in isolations if e['project']==suite['project'] and e['filter']=='FullyQualifiedName='+method]
  assert len(runs)==3 and all(e['exitCode']==0 and int(e['counts']['passed'])>0 for e in runs),(method,runs)
  qualification.append({'project':suite['project'],'method':method,'original_failures':[f for f in suite['failures'] if f['method']==method],'isolated_runs':[e['label'] for e in runs],'seconds':[e['seconds'] for e in runs],'classification':'load flake: 3/3 fresh isolated invocations passed'})
assert all(e['exitCode']==0 for e in isolations)
(out/'flake-qualification.json').write_text(json.dumps(qualification,indent=2)+'\n')
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
skips=[]
for suite in suites:
 doc=ET.parse(scratch/(suite['label']+'.trx'))
 for case in doc.findall('.//t:UnitTestResult',ns):
  if case.get('outcome')=='NotExecuted':skips.append({'project':suite['project'],'name':case.get('testName'),'message':''.join(case.itertext()).strip()})
summary={'build':{'warnings':0,'errors':0},'focused':json.loads((out/'focused-summary.json').read_text()),'showcase':{'passed':len(showcase),'failed':0,'seconds':[e['seconds'] for e in showcase]},'suites':[{k:e[k] for k in ['project','seconds','exitCode','counts','outcomes','skippedCases']} for e in suites],'suite_case_totals':{key:sum(int(e['counts'][key]) for e in suites) for key in ['total','passed','failed']},'qualified_load_flake_methods':len(qualification),'suite_skips':skips,'excluded_git_invoking_guard_classes':['Allegiance.Core.Tests.MeshyGuardTests','Allegiance.Core.Tests.PrivatePathGuardTests']}
summary['suite_case_totals']['skipped']=sum(e['skippedCases'] for e in suites)
(out/'validation-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
rows='\n'.join(f"| {e['project']} | {e['counts']['passed']} | {e['counts']['failed']} | {e['skippedCases']} | {e['seconds']:.1f} |" for e in suites)
totals=summary['suite_case_totals']
text=f'''[Validation summary](P738_HD2_assets/validation-summary.json),
[exact invocation ledger](P738_HD2_assets/verification.json), and
[raw logs/TRX and validation scripts](P738_HD2_assets/validation-logs.tar.gz).

- Whole-solution build: **0 warnings / 0 errors** ([output](P738_HD2_assets/build.txt)).
- **73 methods × 3 fresh exact-method invocations: 318 case passes, 0 failures/skips.**
  Repeats the incoming wave's 33-method inventory (all 14 HD-2 methods plus native
  model/texture/scale/winding, shader and settings checks), every method in the
  resolved P652 file, and the P725 seam/real seated-peer wire guards. The synthetic
  material method draws through real OpenGL, bloom and FSR on each invocation.
  [Method inventory](P738_HD2_assets/targeted-methods.json).
- Showcase never-parks: **5/5 pass**, {', '.join(f"{e['seconds']:.1f}" for e in showcase)} seconds.
  No designated showcase run failed, so the conditional base-rate comparison was
  not triggered.
- Exactly one sweep of each required assembly completed:

| Project | Passed | Failed in sweep | Skipped | Wall seconds |
| --- | ---: | ---: | ---: | ---: |
{rows}

The sweeps recorded **{totals['passed']:,} pass / {totals['failed']} initial failure / {totals['skipped']} skip**
across **{totals['total']:,} cases**. Core excludes only the two guard classes
`MeshyGuardTests` and `PrivatePathGuardTests`, because their implementation
invokes git and this lane forbids git commands. They were not run or counted as
passes; a [supplementary indexed-file review](P738_HD2_assets/hygiene-audit.json)
used read-only index parsing instead. No native/artwork prerequisite was disabled.

The Core transport pool-churn case timed out waiting for `OnPeerJoined` in the
full sweep and then passed **3/3 fresh exact-method reruns** (1.508, 1.520,
1.494 seconds). It meets the brief's load-flake rule and is recorded in
[TEST_FLAKES.md](../TEST_FLAKES.md). The original failure remains in the ledger;
no assertion, deadline, quarantine or simulation behavior was changed.
[Qualification](P738_HD2_assets/flake-qualification.json).

ClientCore completed without failures or skips. MonoGame's skip reasons are
retained verbatim in the validation summary. Real local-network tests ran with
`ALLEGIANCE_LIVE_P660_SHOWCASE=1`, the configured native/artwork corpora and network
access. Rig/221/200v200 opt-ins were not enabled. No second full sweep was run;
Claude's mini runner owns the chain-wide gate. Repository metadata remains
unchanged for the dispatcher to stage and record the resolved working files.
'''
p=root/'docs/reports/HD2_PBR_CLIENT.md';report=p.read_text();report=re.sub(r'<!-- P738_HD2_VALIDATION -->.*?<!-- /P738_HD2_VALIDATION -->',text.rstrip(),report,flags=re.S);p.write_text(report)
p=root/'docs/TEST_FLAKES.md';flakes=p.read_text();assert '### P738 / HD-2 completed assembly sweep' not in flakes
flakes+='\n\n### P738 / HD-2 completed assembly sweep\n\n'+f"The single ClientCore sweep passed **{suites[1]['counts']['passed']}/0/0**. The single MonoGame sweep recorded **{suites[2]['counts']['passed']} pass / {suites[2]['counts']['failed']} fail / {suites[2]['skippedCases']} skip**. The skipped cases and their prerequisite reasons are retained in the [validation summary](reports/P738_HD2_assets/validation-summary.json). The Core transport case above was the only failing method; it passed all three fresh isolated reruns. No second full sweep was run.\n"
p.write_text(flakes)
# Rerun the read-only merge audit after the final documentation edits.
sys.path.insert(0,str(scratch));import audit
assert (root/'docs/reports/HD2_PBR_CLIENT.md').read_bytes().startswith(audit.blob(audit.T,'docs/reports/HD2_PBR_CLIENT.md'))
wd=Path((root/'.git').read_text().strip().split(': ',1)[1]);before=json.loads((scratch/'metadata-before.json').read_text());after={name:hashlib.sha256((wd/name).read_bytes()).hexdigest() for name in before};assert before==after
p=out/'resolution-audit.json';a=json.loads(p.read_text());a.update({'metadata_sha256_unchanged':after,'incoming_report_prefix_preserved':True,'final_validation_complete':True});p.write_text(json.dumps(a,indent=2)+'\n')
# Preserve the commands and outcomes without copying caches or generated art.
with tarfile.open(out/'validation-logs.tar.gz','w:gz') as archive:
 for p in sorted(scratch.iterdir()):
  if p.is_file() and p.suffix in {'.log','.trx','.py','.json'}:archive.add(p,arcname=p.name)
manifest={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(out.iterdir()) if p.is_file() and p.name!='evidence-manifest.json'}
(out/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(summary,indent=2));print('Report, flake notes, final audit, archive and evidence manifest complete.')
