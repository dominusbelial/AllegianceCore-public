import subprocess,os,time,json,re,xml.etree.ElementTree as ET,sys
from collections import Counter
from pathlib import Path
root=Path.cwd();out=root/'docs/reports/P738_HD2_assets';scratch=Path('/tmp/p738-hd2-validation')
env=os.environ.copy();env.update(NUGET_HTTP_CACHE_PATH=str(scratch/'nuget'),ALLEGIANCE_LIVE_P660_SHOWCASE='1',ALSOFT_DRIVERS='null')
for line in (root/'local.env').read_text().splitlines():
 if line and not line.startswith('#') and '=' in line:
  k,v=line.split('=',1);env[k]=v
projects={p:f'tests/Allegiance.{p}.Tests/Allegiance.{p}.Tests.csproj' for p in ['Core','ClientCore','ClientCore.MonoGame']};projects['MonoGame']=projects.pop('ClientCore.MonoGame')
ledger=[];ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
def run(label,project,filter=None):
 trx=scratch/(label+'.trx');cmd=['dotnet','test',projects[project],'--no-build','--nologo','-v:q','--logger','trx;LogFileName='+str(trx)]
 if filter:cmd+=['--filter',filter]
 started=time.monotonic(); print('START',label,project,filter,flush=True)
 with (scratch/(label+'.log')).open('w') as log:p=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
 result={'label':label,'project':project,'filter':filter,'exitCode':p.returncode,'seconds':round(time.monotonic()-started,3)}
 if trx.exists():
  doc=ET.parse(trx);counters=doc.find('.//t:Counters',ns);result['counts']=counters.attrib if counters is not None else {}
  result['outcomes']=dict(Counter(t.get('outcome') for t in doc.findall('.//t:UnitTestResult',ns)));result['skippedCases']=result['outcomes'].get('NotExecuted',0)
  defs={d.get('id'):d.find('t:TestMethod',ns) for d in doc.findall('.//t:UnitTest',ns)}
  result['failures']=[{'name':t.get('testName'),'method':defs[t.get('testId')].get('className')+'.'+defs[t.get('testId')].get('name'),'message':''.join(t.itertext())[-9000:]} for t in doc.findall('.//t:UnitTestResult',ns) if t.get('outcome')=='Failed']
 ledger.append(result);(out/'verification.json').write_text(json.dumps(ledger,indent=2)+'\n');print('END',label,'exit',p.returncode,'seconds',result['seconds'],'counts',result.get('counts',{}),flush=True)
 return result
# Repeat the original incoming wave's complete affected-method inventory, plus
# every method in the conflicted file and the native drone seam/wire guards.
entries=list(dict.fromkeys((e['project'],e['filter']) for e in json.loads((root/'docs/reports/HD2_assets/isolated.json').read_text())))
for project,filename in [('Core','tests/Allegiance.Core.Tests/P652EconomyDroneAiTests.cs'),('Core','tests/Allegiance.Core.Tests/P725DroneChatterSeamTests.cs'),('Core','tests/Allegiance.Core.Tests/P725DroneChatterWireLiveTests.cs')]:
 text=(root/filename).read_text(); cls=re.search(r'public (?:sealed )?class (\w+)',text).group(1)
 for name in re.findall(r'public (?:async )?(?:void|Task) (\w+)\(',text):
  item=(project,'FullyQualifiedName=Allegiance.Core.Tests.'+cls+'.'+name)
  if item not in entries:entries.append(item)
(out/'targeted-methods.json').write_text(json.dumps(entries,indent=2)+'\n')
for project,filter in entries:
 for iteration in range(1,4):run('focused-'+str(len(ledger)+1),project,filter)
for iteration in range(1,6):run('showcase-'+str(iteration),'ClientCore','FullyQualifiedName=Allegiance.ClientCore.Tests.P700ShowcaseLiveTests.Local_showcase_never_parks_with_target_for_five_seconds')
# Exclude only guards which execute git, honoring the user's explicit constraint.
for project in ['Core','ClientCore','MonoGame']:
 filter='FullyQualifiedName!~Allegiance.Core.Tests.MeshyGuardTests&FullyQualifiedName!~Allegiance.Core.Tests.PrivatePathGuardTests' if project=='Core' else None
 result=run('suite-'+project,project,filter)
 # A failed method must pass three fresh invocations before load-flake classification.
 for method in dict.fromkeys(f['method'] for f in result.get('failures',[])):
  for iteration in range(1,4):run('isolation-'+str(len(ledger)+1),project,'FullyQualifiedName='+method)
print('DONE',len(ledger),'invocations',flush=True)
