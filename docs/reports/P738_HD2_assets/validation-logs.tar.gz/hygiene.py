from pathlib import Path
import struct,json,csv
root=Path.cwd();wd=Path((root/'.git').read_text().strip().split(': ',1)[1]);data=(wd/'index').read_bytes();sig,version,count=struct.unpack_from('!4sII',data);assert sig==b'DIRC' and version in (2,3);pos=12;paths=set()
for i in range(count):
 start=pos;flags=struct.unpack_from('!H',data,pos+60)[0];pos+=62
 if flags&0x4000:pos+=2
 end=data.index(b'\0',pos);paths.add(data[pos:end].decode());pos=start+((end+1-start+7)//8)*8
binary={'.dll','.exe','.png','.jpg','.jpeg','.gif','.ico','.woff2','.ogg','.wav','.mp3','.ttf','.mgfxo','.dat','.bin','.pdb','.cov'}
targets={'src','tests','scripts','tools','docker','.github'}
source=[p for p in paths if p.split('/')[0] in targets and Path(p).suffix.lower() not in binary and (root/p).is_file()];assert source
private=[p for p in source if '/home/'+'domingo' in (root/p).read_text(errors='replace')]
model={'.fbx','.fbm','.obj','.glb','.gltf','.blend','.mtl'};media=model|{'.png','.jpg','.jpeg','.gif','.webp','.bmp','.tga','.mp4','.webm'}
locations=('src/Allegiance.ClientCore.MonoGame/Content/Models/','src/Allegiance.ClientCore.MonoGame/Content/Textures/ships/','assets/ships/thumbs/')
meshy=[p for p in paths if p.startswith(locations) or Path(p).suffix.lower() in model or (Path(p).suffix.lower() in media and 'meshy' in p.lower() and not p.startswith(('docs/meshy_hints/','tools/meshy-repair/')))]
with (root/'docs/release/media-inventory.csv').open() as f:
 for row in csv.reader(f):
  if len(row)>=3 and row[2].strip()=='a' and row[0].strip() in paths:meshy.append(row[0].strip())
manifest_docs=[p for p in meshy if p.startswith('src/Allegiance.ClientCore.MonoGame/Content/Models/MODELS_MANIFEST_P287.') and Path(p).suffix in {'.md','.json'}]
generated=[p for p in meshy if p not in manifest_docs]
result={'method':'Supplementary read-only indexed-file review; the git-invoking guard tests themselves were excluded.', 'existing_manifest_documents_under_models':manifest_docs, 'generated_output_offenders':generated,'indexed_paths':len(paths),'source_text_files_checked':len(source),'private_path_offenders':private,'raw_location_or_media_flags':meshy}
(root/'docs/reports/P738_HD2_assets/hygiene-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));assert not private and not generated
